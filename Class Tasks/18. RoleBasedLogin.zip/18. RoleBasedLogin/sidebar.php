<img src="images/Koala.jpg" class="image"/>
<ul class="item">
	<li><img src="images/fb.jpeg" width="20" height="15">&nbsp;<a href="">Home</a></li>
	<li><img src="images/me.png" width="20" height="15">&nbsp;<a href="">Profile</a></li>
	<li><a href="">News</a></li>
	<li><a href="">Likes</a></li>
</ul>